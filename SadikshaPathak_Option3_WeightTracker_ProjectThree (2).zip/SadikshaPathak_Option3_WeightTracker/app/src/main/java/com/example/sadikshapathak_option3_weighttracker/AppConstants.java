package com.example.sadikshapathak_option3_weighttracker;

/**
 * Values shared by more than one screen. Keeping them in one place prevents
 * typos in the keys that the screens use to pass data to each other.
 */
public final class AppConstants {

    /** Intent extra that carries the logged-in user's database id between screens. */
    public static final String EXTRA_USER_ID = "com.example.sadikshapathak_option3_weighttracker.USER_ID";

    /** Value used when no user is logged in. */
    public static final long NO_USER = -1;

    private AppConstants() {
        // Constants only, so this class should never be created.
    }
}
