package com.example.sadikshapathak_option3_weighttracker;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.text.TextUtils;

import androidx.core.content.ContextCompat;

/**
 * Sends the goal weight text message. Both screens that send SMS use this class,
 * so the permission check lives in exactly one place.
 */
public final class SmsNotifier {

    private SmsNotifier() {
        // Helper methods only, so this class should never be created.
    }

    /** @return true if the user has allowed this app to send text messages */
    public static boolean hasPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Sends the "you reached your goal" text.
     * Nothing is sent, and no error is shown, when permission is missing. The rest of
     * the app keeps working without the SMS feature.
     *
     * @return true only if the message was handed to the phone's SMS service
     */
    public static boolean sendGoalAlert(Context context, String phoneNumber) {
        if (!hasPermission(context) || TextUtils.isEmpty(phoneNumber)) {
            return false;
        }

        try {
            SmsManager smsManager = context.getSystemService(SmsManager.class);
            if (smsManager == null) {
                return false; // This device has no SMS service, such as some tablets.
            }
            smsManager.sendTextMessage(phoneNumber, null,
                    context.getString(R.string.sms_goal_message), null, null);
            return true;
        } catch (RuntimeException e) {
            // Covers a bad phone number or permission being removed while the app was open.
            return false;
        }
    }
}
