package com.example.sadikshapathak_option3_weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Main screen after login. Shows the user's daily weights in a grid and lets them
 * add, edit, and delete weights and set a goal weight. When the goal is reached,
 * it sends an SMS if the user allowed it.
 */
public class WeightHistoryActivity extends AppCompatActivity {

    private static final double MAX_WEIGHT = 1500;
    private static final DateTimeFormatter GRID_DATE_FORMAT =
            DateTimeFormatter.ofPattern("MMM d", Locale.US);

    private DatabaseHelper database;
    private long userId;

    // The weights currently shown in the grid, newest first.
    private List<WeightEntry> entries = new ArrayList<>();

    private TableLayout tableWeights;
    private TextView textEmptyGrid;
    private TextView textSummaryGoal;
    private TextView textSummaryLatest;
    private TextView textSummaryToGo;
    private TextInputLayout layoutWeight;
    private TextInputLayout layoutGoalWeight;
    private TextInputEditText editWeight;
    private TextInputEditText editGoalWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Without a logged-in user there is nothing to show, so go back to the login screen.
        userId = getIntent().getLongExtra(AppConstants.EXTRA_USER_ID, AppConstants.NO_USER);
        if (userId == AppConstants.NO_USER) {
            finish();
            return;
        }

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_weight_history);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Same fade transition as the other screens.
        overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, android.R.anim.fade_in, android.R.anim.fade_out);
        overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, android.R.anim.fade_in, android.R.anim.fade_out);

        database = new DatabaseHelper(this);
        findViews();

        // Alerts opens the SMS notification screen for this same user.
        findViewById(R.id.buttonAlerts).setOnClickListener(v -> {
            Intent intent = new Intent(this, SmsNotificationActivity.class);
            intent.putExtra(AppConstants.EXTRA_USER_ID, userId);
            startActivity(intent);
        });

        // Log Out closes this screen and returns to the login screen.
        findViewById(R.id.buttonLogOut).setOnClickListener(v -> finish());

        findViewById(R.id.buttonAddWeight).setOnClickListener(v -> addTodaysWeight());
        findViewById(R.id.buttonSaveGoal).setOnClickListener(v -> saveGoal());

        // Show any goal that was saved earlier, then fill in the grid and summary.
        Double savedGoal = database.getGoalWeight(userId);
        if (savedGoal != null) {
            editGoalWeight.setText(formatWeight(savedGoal));
        }
        refreshScreen();
    }

    @Override
    protected void onDestroy() {
        if (database != null) {
            database.close();
        }
        super.onDestroy();
    }

    private void findViews() {
        tableWeights = findViewById(R.id.tableWeights);
        textEmptyGrid = findViewById(R.id.textEmptyGrid);
        textSummaryGoal = findViewById(R.id.textSummaryGoal);
        textSummaryLatest = findViewById(R.id.textSummaryLatest);
        textSummaryToGo = findViewById(R.id.textSummaryToGo);
        layoutWeight = findViewById(R.id.layoutWeight);
        layoutGoalWeight = findViewById(R.id.layoutGoalWeight);
        editWeight = findViewById(R.id.editWeight);
        editGoalWeight = findViewById(R.id.editGoalWeight);
    }

    // ---------------------------------------------------------------------
    // Button actions
    // ---------------------------------------------------------------------

    /** Create: saves the typed weight for today's date. */
    private void addTodaysWeight() {
        layoutWeight.setError(null);

        Double weight = parseWeight(textOf(editWeight));
        if (weight == null) {
            layoutWeight.setError(getString(R.string.error_weight_invalid));
            editWeight.requestFocus();
            return;
        }

        database.addOrReplaceWeight(userId, LocalDate.now().toString(), weight);
        editWeight.setText("");
        Toast.makeText(this, R.string.weight_saved, Toast.LENGTH_SHORT).show();
        refreshScreen();
        checkGoalReached();
    }

    /** Saves the goal weight. The goal is stored once and can be replaced later. */
    private void saveGoal() {
        layoutGoalWeight.setError(null);

        Double goal = parseWeight(textOf(editGoalWeight));
        if (goal == null) {
            layoutGoalWeight.setError(getString(R.string.error_weight_invalid));
            editGoalWeight.requestFocus();
            return;
        }

        database.saveGoalWeight(userId, goal);
        Toast.makeText(this, R.string.goal_saved, Toast.LENGTH_SHORT).show();
        refreshScreen();
        checkGoalReached();
    }

    /** Update: asks for a new value for one grid row. */
    private void showEditDialog(WeightEntry entry, String dateLabel) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(formatWeight(entry.getWeight()));
        input.setSelectAllOnFocus(true);
        input.setContentDescription(getString(R.string.hint_weight));

        // The container adds side padding so the field lines up with the dialog title.
        FrameLayout container = new FrameLayout(this);
        int padding = (int) (24 * getResources().getDisplayMetrics().density);
        container.setPadding(padding, padding / 2, padding, 0);
        container.addView(input, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        new MaterialAlertDialogBuilder(this)
                .setTitle(getString(R.string.edit_dialog_title, dateLabel))
                .setView(container)
                .setPositiveButton(R.string.button_save, (dialog, which) -> {
                    Double newWeight = parseWeight(input.getText().toString());
                    if (newWeight == null) {
                        Toast.makeText(this, R.string.error_weight_invalid, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    database.updateWeight(entry.getId(), newWeight);
                    refreshScreen();
                    checkGoalReached();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    /** Delete: removes one row from the database and the grid. */
    private void deleteEntry(WeightEntry entry) {
        database.deleteWeight(entry.getId());
        Toast.makeText(this, R.string.weight_deleted, Toast.LENGTH_SHORT).show();
        refreshScreen();
    }

    // ---------------------------------------------------------------------
    // Drawing the grid and summary
    // ---------------------------------------------------------------------

    /** Reads the database again and redraws the grid and the summary card. */
    private void refreshScreen() {
        entries = database.getWeights(userId);
        drawGrid();
        drawSummary();
    }

    /** Read: shows every saved weight as one grid row, with Edit and Delete buttons. */
    private void drawGrid() {
        // Keep the header row (index 0) and remove the old data rows.
        if (tableWeights.getChildCount() > 1) {
            tableWeights.removeViews(1, tableWeights.getChildCount() - 1);
        }

        textEmptyGrid.setVisibility(entries.isEmpty() ? TextView.VISIBLE : TextView.GONE);

        for (int i = 0; i < entries.size(); i++) {
            WeightEntry entry = entries.get(i);
            String dateLabel = LocalDate.parse(entry.getDate()).format(GRID_DATE_FORMAT);

            TableRow row = (TableRow) getLayoutInflater()
                    .inflate(R.layout.item_weight_row, tableWeights, false);

            // Alternate the row color so long grids are easier to read.
            int colorId = (i % 2 == 0) ? R.color.wt_surface : R.color.wt_row_alt;
            row.setBackgroundColor(ContextCompat.getColor(this, colorId));

            ((TextView) row.findViewById(R.id.textRowDate)).setText(dateLabel);
            ((TextView) row.findViewById(R.id.textRowWeight)).setText(formatWeight(entry.getWeight()));

            row.findViewById(R.id.buttonEditRow).setContentDescription(
                    getString(R.string.edit_row_description, dateLabel));
            row.findViewById(R.id.buttonEditRow).setOnClickListener(v -> showEditDialog(entry, dateLabel));

            row.findViewById(R.id.buttonDeleteRow).setContentDescription(
                    getString(R.string.delete_row_description, dateLabel));
            row.findViewById(R.id.buttonDeleteRow).setOnClickListener(v -> deleteEntry(entry));

            tableWeights.addView(row);
        }
    }

    /** Fills in the Goal, Latest, and To go values at the top of the screen. */
    private void drawSummary() {
        Double goal = database.getGoalWeight(userId);
        boolean hasLatest = !entries.isEmpty();

        textSummaryGoal.setText(goal == null
                ? getString(R.string.summary_empty)
                : getString(R.string.weight_with_unit, formatWeight(goal)));

        textSummaryLatest.setText(!hasLatest
                ? getString(R.string.summary_empty)
                : getString(R.string.weight_with_unit, formatWeight(entries.get(0).getWeight())));

        if (goal == null || !hasLatest) {
            textSummaryToGo.setText(R.string.summary_empty);
        } else if (isGoalReached(goal)) {
            textSummaryToGo.setText(getString(R.string.weight_with_unit, formatWeight(0)));
        } else {
            double remaining = Math.abs(entries.get(0).getWeight() - goal);
            textSummaryToGo.setText(getString(R.string.weight_with_unit, formatWeight(remaining)));
        }
    }

    // ---------------------------------------------------------------------
    // Goal weight and SMS alert
    // ---------------------------------------------------------------------

    /**
     * True when the latest weight has reached the goal. The first weight the user
     * logged shows whether the goal is to lose weight or to gain weight.
     */
    private boolean isGoalReached(double goal) {
        if (entries.isEmpty()) {
            return false;
        }
        double latest = entries.get(0).getWeight();
        double first = entries.get(entries.size() - 1).getWeight();
        return first >= goal ? latest <= goal : latest >= goal;
    }

    /**
     * Sends the SMS alert once when the goal is reached. If the user denied SMS permission
     * or has not saved a phone number, nothing is sent and the app keeps working normally.
     */
    private void checkGoalReached() {
        Double goal = database.getGoalWeight(userId);
        if (goal == null || !isGoalReached(goal) || database.isGoalAlertSent(userId)) {
            return;
        }

        String phone = database.getPhoneNumber(userId);
        if (SmsNotifier.sendGoalAlert(this, phone)) {
            database.markGoalAlertSent(userId);
            Toast.makeText(this, R.string.goal_alert_sent, Toast.LENGTH_LONG).show();
        }
    }

    // ---------------------------------------------------------------------
    // Small helpers
    // ---------------------------------------------------------------------

    /**
     * Turns typed text into a weight.
     *
     * @return the weight, or null if the text is empty, not a number, or out of range
     */
    private Double parseWeight(String text) {
        try {
            // Some keyboards type a comma for the decimal point, so accept both.
            double value = Double.parseDouble(text.trim().replace(',', '.'));
            return (value > 0 && value <= MAX_WEIGHT) ? value : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String formatWeight(double weight) {
        return String.format(Locale.US, "%.1f", weight);
    }

    private String textOf(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString();
    }
}
