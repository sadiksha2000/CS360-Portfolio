package com.example.sadikshapathak_option3_weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Creates the SQLite database and is the only class that runs SQL.
 * The screens call these methods and never write SQL themselves.
 *
 * Tables:
 *   users   - login name, salted password hash, and the phone number for SMS alerts
 *   weights - one row per daily weight, linked to a user
 *   goals   - one goal weight per user, plus a flag that says if the SMS alert was sent
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weighttracker.db";
    private static final int DATABASE_VERSION = 1;

    // users table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "user_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_HASH = "password_hash";
    private static final String COL_SALT = "salt";
    private static final String COL_PHONE = "phone_number";

    // weights table
    private static final String TABLE_WEIGHTS = "weights";
    private static final String COL_WEIGHT_ID = "weight_id";
    private static final String COL_ENTRY_DATE = "entry_date";
    private static final String COL_WEIGHT = "weight";

    // goals table
    private static final String TABLE_GOALS = "goals";
    private static final String COL_GOAL_ID = "goal_id";
    private static final String COL_GOAL_WEIGHT = "goal_weight";
    private static final String COL_NOTIFIED = "notified";

    // Password hashing settings. A slow hash makes guessing passwords harder.
    private static final int HASH_ITERATIONS = 100_000;
    private static final int HASH_BITS = 256;
    private static final int SALT_BYTES = 16;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        // Needed so deleting a user also deletes that user's weights and goal.
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT NOT NULL UNIQUE, "
                + COL_PASSWORD_HASH + " TEXT NOT NULL, "
                + COL_SALT + " TEXT NOT NULL, "
                + COL_PHONE + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " ("
                + COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USER_ID + " INTEGER NOT NULL, "
                + COL_ENTRY_DATE + " TEXT NOT NULL, "
                + COL_WEIGHT + " REAL NOT NULL, "
                + "FOREIGN KEY(" + COL_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + ") ON DELETE CASCADE)");

        db.execSQL("CREATE TABLE " + TABLE_GOALS + " ("
                + COL_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USER_ID + " INTEGER NOT NULL UNIQUE, "
                + COL_GOAL_WEIGHT + " REAL NOT NULL, "
                + COL_NOTIFIED + " INTEGER NOT NULL DEFAULT 0, "
                + "FOREIGN KEY(" + COL_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + ") ON DELETE CASCADE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Only version 1 exists so far. A later version would migrate the data here.
    }

    // ---------------------------------------------------------------------
    // Users: create an account and log in
    // ---------------------------------------------------------------------

    /**
     * Saves a new login.
     *
     * @return the new user's id, or AppConstants.NO_USER if that username is already taken
     */
    public long createUser(String username, String password) {
        if (usernameExists(username)) {
            return AppConstants.NO_USER;
        }

        String salt = newSalt();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_SALT, salt);
        values.put(COL_PASSWORD_HASH, hashPassword(password, salt));

        long id = getWritableDatabase().insert(TABLE_USERS, null, values);
        return id == -1 ? AppConstants.NO_USER : id;
    }

    /**
     * Checks a username and password against the saved logins.
     *
     * @return the user's id if they match, otherwise AppConstants.NO_USER
     */
    public long authenticate(String username, String password) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_USERS,
                new String[]{COL_USER_ID, COL_PASSWORD_HASH, COL_SALT},
                COL_USERNAME + " = ?", new String[]{username}, null, null, null)) {

            if (!cursor.moveToFirst()) {
                return AppConstants.NO_USER;
            }

            String savedHash = cursor.getString(1);
            String attemptHash = hashPassword(password, cursor.getString(2));

            // isEqual compares in constant time so timing does not leak the hash.
            boolean matches = MessageDigest.isEqual(
                    savedHash.getBytes(StandardCharsets.UTF_8),
                    attemptHash.getBytes(StandardCharsets.UTF_8));
            return matches ? cursor.getLong(0) : AppConstants.NO_USER;
        }
    }

    private boolean usernameExists(String username) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_USERS,
                new String[]{COL_USER_ID}, COL_USERNAME + " = ?", new String[]{username},
                null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    // ---------------------------------------------------------------------
    // Phone number used for the SMS goal alert
    // ---------------------------------------------------------------------

    public void savePhoneNumber(long userId, String phone) {
        ContentValues values = new ContentValues();
        values.put(COL_PHONE, phone);
        getWritableDatabase().update(TABLE_USERS, values, COL_USER_ID + " = ?",
                new String[]{String.valueOf(userId)});
    }

    /** @return the saved phone number, or an empty string if none has been saved */
    public String getPhoneNumber(long userId) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_USERS,
                new String[]{COL_PHONE}, COL_USER_ID + " = ?", new String[]{String.valueOf(userId)},
                null, null, null)) {
            if (cursor.moveToFirst() && !cursor.isNull(0)) {
                return cursor.getString(0);
            }
            return "";
        }
    }

    // ---------------------------------------------------------------------
    // Weights: create, read, update, delete
    // ---------------------------------------------------------------------

    /**
     * Create: saves the weight for a date. A day can only have one weight, so if
     * that date already has a row, the existing row is updated instead.
     */
    public void addOrReplaceWeight(long userId, String isoDate, double weight) {
        long existingId = findWeightIdByDate(userId, isoDate);
        if (existingId != -1) {
            updateWeight(existingId, weight);
            return;
        }

        ContentValues values = new ContentValues();
        values.put(COL_USER_ID, userId);
        values.put(COL_ENTRY_DATE, isoDate);
        values.put(COL_WEIGHT, weight);
        getWritableDatabase().insert(TABLE_WEIGHTS, null, values);
    }

    /** Read: all of a user's weights, newest first, for the grid. */
    public List<WeightEntry> getWeights(long userId) {
        List<WeightEntry> entries = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(TABLE_WEIGHTS,
                new String[]{COL_WEIGHT_ID, COL_ENTRY_DATE, COL_WEIGHT},
                COL_USER_ID + " = ?", new String[]{String.valueOf(userId)},
                null, null, COL_ENTRY_DATE + " DESC, " + COL_WEIGHT_ID + " DESC")) {
            while (cursor.moveToNext()) {
                entries.add(new WeightEntry(cursor.getLong(0), cursor.getString(1), cursor.getDouble(2)));
            }
        }
        return entries;
    }

    /** Update: changes the weight value of one existing row. */
    public void updateWeight(long weightId, double newWeight) {
        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT, newWeight);
        getWritableDatabase().update(TABLE_WEIGHTS, values, COL_WEIGHT_ID + " = ?",
                new String[]{String.valueOf(weightId)});
    }

    /** Delete: removes one row from the grid. */
    public void deleteWeight(long weightId) {
        getWritableDatabase().delete(TABLE_WEIGHTS, COL_WEIGHT_ID + " = ?",
                new String[]{String.valueOf(weightId)});
    }

    private long findWeightIdByDate(long userId, String isoDate) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_WEIGHTS,
                new String[]{COL_WEIGHT_ID},
                COL_USER_ID + " = ? AND " + COL_ENTRY_DATE + " = ?",
                new String[]{String.valueOf(userId), isoDate}, null, null, null)) {
            return cursor.moveToFirst() ? cursor.getLong(0) : -1;
        }
    }

    // ---------------------------------------------------------------------
    // Goal weight
    // ---------------------------------------------------------------------

    /**
     * Saves the goal weight, replacing any earlier goal. A new goal also clears the
     * "alert sent" flag, so the user gets a new text when they reach the new goal.
     */
    public void saveGoalWeight(long userId, double goalWeight) {
        ContentValues values = new ContentValues();
        values.put(COL_USER_ID, userId);
        values.put(COL_GOAL_WEIGHT, goalWeight);
        values.put(COL_NOTIFIED, 0);
        // The user_id column is UNIQUE, so REPLACE overwrites the old goal row.
        getWritableDatabase().insertWithOnConflict(TABLE_GOALS, null, values,
                SQLiteDatabase.CONFLICT_REPLACE);
    }

    /** @return the goal weight, or null if the user has not set one yet */
    public Double getGoalWeight(long userId) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_GOALS,
                new String[]{COL_GOAL_WEIGHT}, COL_USER_ID + " = ?",
                new String[]{String.valueOf(userId)}, null, null, null)) {
            return cursor.moveToFirst() ? cursor.getDouble(0) : null;
        }
    }

    /** @return true if the SMS alert for the current goal was already sent */
    public boolean isGoalAlertSent(long userId) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_GOALS,
                new String[]{COL_NOTIFIED}, COL_USER_ID + " = ?",
                new String[]{String.valueOf(userId)}, null, null, null)) {
            return cursor.moveToFirst() && cursor.getInt(0) == 1;
        }
    }

    public void markGoalAlertSent(long userId) {
        ContentValues values = new ContentValues();
        values.put(COL_NOTIFIED, 1);
        getWritableDatabase().update(TABLE_GOALS, values, COL_USER_ID + " = ?",
                new String[]{String.valueOf(userId)});
    }

    // ---------------------------------------------------------------------
    // Password helpers
    // ---------------------------------------------------------------------

    private static String newSalt() {
        byte[] salt = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(salt);
        return Base64.encodeToString(salt, Base64.NO_WRAP);
    }

    /** Turns a password and salt into a hash. The plain password is never saved. */
    private static String hashPassword(String password, String salt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(),
                    Base64.decode(salt, Base64.NO_WRAP), HASH_ITERATIONS, HASH_BITS);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            return Base64.encodeToString(factory.generateSecret(spec).getEncoded(), Base64.NO_WRAP);
        } catch (GeneralSecurityException e) {
            // Every Android version this app supports includes this algorithm.
            throw new IllegalStateException("Password hashing is not available", e);
        }
    }
}
