package com.example.sadikshapathak_option3_weighttracker;

/**
 * One row of the weight grid: a single daily weight that belongs to one user.
 * This is a plain data holder, so it has no logic of its own.
 */
public class WeightEntry {

    private final long id;
    private final String date;   // stored as ISO text, for example "2026-10-18"
    private final double weight; // pounds

    public WeightEntry(long id, String date, double weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    public long getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public double getWeight() {
        return weight;
    }
}
