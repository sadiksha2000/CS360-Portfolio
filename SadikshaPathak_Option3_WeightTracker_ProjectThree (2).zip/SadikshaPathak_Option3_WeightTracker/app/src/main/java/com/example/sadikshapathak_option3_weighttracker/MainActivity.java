package com.example.sadikshapathak_option3_weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * Login screen. The same screen logs in returning users and creates a login
 * for new users, and both paths use the database.
 */
public class MainActivity extends AppCompatActivity {

    private static final int MIN_PASSWORD_LENGTH = 4;

    private DatabaseHelper database;
    private TextInputLayout layoutUsername;
    private TextInputLayout layoutPassword;
    private TextInputEditText editUsername;
    private TextInputEditText editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Every screen uses the same fade transition when it opens and closes.
        overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, android.R.anim.fade_in, android.R.anim.fade_out);
        overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, android.R.anim.fade_in, android.R.anim.fade_out);

        database = new DatabaseHelper(this);

        layoutUsername = findViewById(R.id.layoutUsername);
        layoutPassword = findViewById(R.id.layoutPassword);
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        findViewById(R.id.buttonLogin).setOnClickListener(v -> attemptLogin());
        findViewById(R.id.buttonCreateAccount).setOnClickListener(v -> attemptCreateAccount());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // After logging out, clear the password so the next person has to type it again.
        if (editPassword.getText() != null) {
            editPassword.getText().clear();
        }
    }

    @Override
    protected void onDestroy() {
        database.close();
        super.onDestroy();
    }

    /** Checks the typed username and password against the users table. */
    private void attemptLogin() {
        if (!fieldsAreFilledIn()) {
            return;
        }

        long userId = database.authenticate(textOf(editUsername), passwordOf());
        if (userId == AppConstants.NO_USER) {
            // One message for both cases, so the app does not reveal which usernames exist.
            layoutPassword.setError(getString(R.string.error_login_failed));
            return;
        }
        openWeightHistory(userId);
    }

    /** Saves a new username and password to the users table, then logs the user in. */
    private void attemptCreateAccount() {
        if (!fieldsAreFilledIn()) {
            return;
        }

        if (passwordOf().length() < MIN_PASSWORD_LENGTH) {
            layoutPassword.setError(getString(R.string.error_password_short, MIN_PASSWORD_LENGTH));
            editPassword.requestFocus();
            return;
        }

        long userId = database.createUser(textOf(editUsername), passwordOf());
        if (userId == AppConstants.NO_USER) {
            layoutUsername.setError(getString(R.string.error_username_taken));
            editUsername.requestFocus();
            return;
        }
        openWeightHistory(userId);
    }

    /** Shows an error under each empty field. @return true when both fields have text */
    private boolean fieldsAreFilledIn() {
        layoutUsername.setError(null);
        layoutPassword.setError(null);

        if (TextUtils.isEmpty(textOf(editUsername))) {
            layoutUsername.setError(getString(R.string.error_username_required));
            editUsername.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(passwordOf())) {
            layoutPassword.setError(getString(R.string.error_password_required));
            editPassword.requestFocus();
            return false;
        }
        return true;
    }

    private void openWeightHistory(long userId) {
        Intent intent = new Intent(this, WeightHistoryActivity.class);
        intent.putExtra(AppConstants.EXTRA_USER_ID, userId);
        startActivity(intent);
    }

    /** Passwords are not trimmed, because spaces can be part of a password. */
    private String passwordOf() {
        return editPassword.getText() == null ? "" : editPassword.getText().toString();
    }

    private String textOf(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }
}
