package com.example.sadikshapathak_option3_weighttracker;

import android.Manifest;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * Asks the user for SMS permission, saves the phone number for alerts, and can send a
 * test message. If the user says no, the rest of the app still works.
 */
public class SmsNotificationActivity extends AppCompatActivity {

    private DatabaseHelper database;
    private long userId;

    private TextView textPermissionStatus;
    private TextView textSmsMessage;
    private TextInputLayout layoutPhone;
    private TextInputEditText editPhone;

    // Shows the system permission dialog and reports the user's answer.
    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                    this::showPermissionState);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Without a logged-in user there is no phone number to save, so close this screen.
        userId = getIntent().getLongExtra(AppConstants.EXTRA_USER_ID, AppConstants.NO_USER);
        if (userId == AppConstants.NO_USER) {
            finish();
            return;
        }

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_notification);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Same fade transition as the other screens.
        overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, android.R.anim.fade_in, android.R.anim.fade_out);
        overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, android.R.anim.fade_in, android.R.anim.fade_out);

        database = new DatabaseHelper(this);

        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        textSmsMessage = findViewById(R.id.textSmsMessage);
        layoutPhone = findViewById(R.id.layoutPhone);
        editPhone = findViewById(R.id.editPhone);

        // Show the phone number saved earlier, if there is one.
        editPhone.setText(database.getPhoneNumber(userId));

        // If the user already allowed SMS earlier, show that right away.
        if (SmsNotifier.hasPermission(this)) {
            showPermissionState(true);
        }

        findViewById(R.id.buttonEnableSms).setOnClickListener(v -> {
            if (SmsNotifier.hasPermission(this)) {
                showPermissionState(true);
            } else {
                permissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        findViewById(R.id.buttonSavePhone).setOnClickListener(v -> {
            if (savePhoneNumber()) {
                Toast.makeText(this, R.string.phone_saved, Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.buttonSendTest).setOnClickListener(v -> sendTestMessage());
        findViewById(R.id.buttonBackToLog).setOnClickListener(v -> finish());
    }

    @Override
    protected void onDestroy() {
        if (database != null) {
            database.close();
        }
        super.onDestroy();
    }

    /** Updates the status and message to match the user's response. */
    private void showPermissionState(boolean granted) {
        if (granted) {
            textPermissionStatus.setText(R.string.sms_status_granted);
            textPermissionStatus.setTextColor(ContextCompat.getColor(this, R.color.wt_success));
            textSmsMessage.setText(R.string.sms_message_granted);
        } else {
            textPermissionStatus.setText(R.string.sms_status_denied);
            textPermissionStatus.setTextColor(ContextCompat.getColor(this, R.color.wt_error));
            textSmsMessage.setText(R.string.sms_message_denied);
        }
    }

    /**
     * Saves the typed phone number to the database.
     *
     * @return true if the number was valid and saved
     */
    private boolean savePhoneNumber() {
        layoutPhone.setError(null);

        String phone = editPhone.getText() == null ? "" : editPhone.getText().toString().trim();
        if (TextUtils.isEmpty(phone) || !Patterns.PHONE.matcher(phone).matches()) {
            layoutPhone.setError(getString(R.string.sms_phone_required));
            editPhone.requestFocus();
            return false;
        }

        database.savePhoneNumber(userId, phone);
        return true;
    }

    private void sendTestMessage() {
        // Always check the permission before sending. If it is missing, ask for it.
        if (!SmsNotifier.hasPermission(this)) {
            permissionLauncher.launch(Manifest.permission.SEND_SMS);
            return;
        }

        if (!savePhoneNumber()) {
            return;
        }

        String phone = editPhone.getText().toString().trim();
        boolean sent = SmsNotifier.sendGoalAlert(this, phone);
        Toast.makeText(this, sent ? R.string.sms_test_sent : R.string.sms_test_failed,
                sent ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG).show();
    }
}
